/** @type {import('tailwindcss').Config} */
module.exports = {
content: ["./**/*.html"],

  theme: {
    fontFamily:{
      digikala:["digikala"],
      noneEnglish:["noneEnglish"]
    },
    extend: {},
  },
  plugins: [],
}

