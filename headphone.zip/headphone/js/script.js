// *start  pictures//
const image = document.querySelector("#image>img");
const thumpnails = document.querySelectorAll(".thumpnail>div>img");
console.log(image);

thumpnails.forEach((elem) => {
  elem.addEventListener("click", () => {
    image.src = `${elem.src}`;
  });
});
// *end  pictures//
//*start click//
const clicks = document.querySelectorAll(".click");
clicks.forEach((elem) => {
  elem.addEventListener("mouseenter", () => {
    elem.classList.add("animate__pulse");
  });
});

//*start invesiblebox//
$(document).ready(function () {
  $(".btncommnts").on("click", () => {
    $(".invesublebox")
      .removeClass("opacity-0  h-0   translate-y-0")
      .addClass("opacity-100 h-[320px]");
  });
});
$(document).ready(function () {
  $(".btndelete").on("click", () => {
    $(".invesublebox")
      .addClass("opacity-0   h-0  translate-y-0")
      .removeClass("opacity-100  h-[320px] translate-y-0");
  });
});
//*start swiper//
$(document).ready(() => {
  $(document).on("scroll", () => {
    let st = $(window).scrollTop();
console.log(st);

    if (st > 1200) {
      $(".swiper").fadeIn(800).addClass("animate__animated   animate__fadeInRight   animate__delay-1s");
    } 

  });
});
