let name = document.querySelector(".name");
let height = document.querySelector(".height");
let weight = document.querySelector(".weight");
const submit = document.querySelector("#submit");
let res = document.querySelector("#res");
submit.addEventListener("click", () => {
  let h = height.value;
  let w = weight.value;
  let bmi = w / (h * h);
  let number = Math.floor(bmi);
  res.innerHTML = number;
  res.classList.remove("hidden");
  res.classList.add("block");
  res.style.transition = "none";
  if (number < 18.5) {
    res.style.backgroundColor = "blue";
    res.classList.add("animate__bounce");
  } else if (number > 18.5 && number < 24.9) {
    res.style.backgroundColor = "lawngreen";
    res.classList.add("animate__bounce");
  } else if (number > 25 && number < 29.9) {
    res.style.backgroundColor = "yellow";
    res.classList.add("animate__bounce");
  } else if (number > 30 && number < 34.9) {
    res.style.backgroundColor = "saddlebrown";
    res.classList.add("animate__bounce");
  } else if (number > 35) {
    res.style.backgroundColor = "red";
    res.classList.add("animate__bounce");
  }
});
