const input = document.querySelector("#input");
const add = document.querySelector("#add");
const ul = document.querySelector("ul");

function createElement() {
  const li = document.createElement("li");
  li.classList.add(
    "bg-white",
    "2xl:w-[330px]",
    "xl:w-[410px]",
    "lg:w-[330px]",
    "md:w-[355px]",
    "sm:w-[270px]",
    "mt-[20px]",
    "px-[12px]",
    "py-[15px]",
    "font-Libre",
    "rounded-[8px]",
    "text-[17px]",
    "font-bold",
    "flex",
    "items-center",
    "gap-3"
  );

  const dtick = document.createElement("img");
  dtick.src = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/BlueFlat_tick_icon.svg/512px-BlueFlat_tick_icon.svg.png?20180311031112";
  dtick.alt = "tick icon";
  dtick.classList.add("w-[24px]", "h-[24px]", "cursor-pointer");

  const dBtn = document.createElement("button");
  dBtn.innerText = "X";
  dBtn.classList.add( "text-black", "rounded", "px-2" ,"transition");

  const span = document.createElement("span");
  span.textContent = input.value;
  span.classList.add("font-Libre");
  input.value = "";

  li.appendChild(dtick); // اول تیک
  li.appendChild(dBtn);  // بعد دکمه حذف
  li.appendChild(span);  // بعد متن

  ul.appendChild(li);

  dBtn.addEventListener("click", () => li.classList.add("hidden"));
  dtick.addEventListener("click", () => span.classList.add("line-through", "text-black"));
  li.addEventListener("click", () => li.classList.add("bg-[#FFD700]", "transition-all", "duration-500"));
}
function inputlenght() {
  return input.value.length;
}
function addafterenter() {
  if (inputlenght() > 0 && event.which == 13) {
    createElement();
  }
}
function addafterclick() {
  if (inputlenght() > 0) {
    createElement();
  }
}

add.addEventListener("click", addafterclick);
input.addEventListener("keypress", addafterenter);
